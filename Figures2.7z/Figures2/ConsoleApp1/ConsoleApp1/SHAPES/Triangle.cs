﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.SHAPES
{
    class Triangle : BaseShapecs
    {
        int first, second, third, height;


        public Triangle( int a, int b, int c, int h )
        {
            first = a;
            second = b;
            third = c;
            height = h;

            this.sides = 3;

        }

        public override  double Perimeter()
        {
            this.perimeter = first + second;

            return this.perimeter;
        }

        public override double Area()
        {
            this.area = (first * height) / 2;

            return this.area;
        }

        public new void Properties()
        {
            Console.WriteLine("Invoked in derived class");

        }

        public void GetProperties()
        {
            this.Properties();

            base.Properties();

            

            Console.Write(" and i have {0} sides", this.sides);
            Console.WriteLine();
        }
    }
}
