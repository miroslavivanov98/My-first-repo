﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.SHAPES
{
    class Rectangle : BaseShapecs
    {
        int width, height;

        public Rectangle(int a, int b)
        {
            width = a;
            height = b;
        }

        public override double Perimeter()
        {
            this.perimeter = 2 * (width + height);

            return this.perimeter;
        }

        public override double Area()
        {
            this.area = width * height;

            return this.area;
        }

    }
}
