﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.SHAPES
{
    abstract class BaseShapecs
    {
        protected double perimeter;
        protected double area;
        protected int sides;

        abstract public double Perimeter();
        abstract public double Area();

        public virtual void Properties()
        {
            Console.WriteLine("Invoked in base class");

            Console.Write("I am {0}", this.GetType().ToString());
        }
    }
}
