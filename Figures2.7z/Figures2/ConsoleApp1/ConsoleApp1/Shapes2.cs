﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figures
{
    class Shapes2
    {
        protected double perimeter;
        protected double area;

        string type;

        int width;
        int height;


        public Shapes2(string type, int width, int height)
        {
            this.type = type;
            this.width = width;
            this.height = height;
        }

        public double Perimeter()
        {
            return this.perimeter;
        }

        private double RectangleArea(int a, int b)
        {
            return a * b;
        }

        public double Area()
        {
            switch(this.type)
            {

                case "rectangle":
                    this.area = RectangleArea(width, height);
                    break;

                case "square":
                    this.area = width * height;
                    break;

            }

            return this.area;
        }
    }
}
