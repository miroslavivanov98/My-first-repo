﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figures
{
    using ConsoleApp1.SHAPES;
    class Program
    {
        static void Main(string[] args)
        {
            Triangle Triangle = new Triangle(100, 100, 100, 10);
            Rectangle Rectangle = new Rectangle(10, 20);
            Square Square = new Square(10);

			List<object> MixedList = new List<object>();

			MixedList.Add("First sequence: ");
			
			for(int i=1; i<6; i++)
			{
				MixedList.Add(i);
			}

			MixedList.Add("Second sequence: ");

			for (int i = 6; i < 11; i++)
			{
				MixedList.Add(i);
			}

			int sum = 0;
			foreach(var value in MixedList)
			{
				Console.WriteLine(value);
				if(value is int)
					{
						sum += (int)value;
					}
				
			}
			Console.WriteLine("Sum of all elements is : {0}", sum);
			return;

			List<BaseShapecs> TriangleList = new List<BaseShapecs>()
			{

			};



            Console.WriteLine("Area of Triangle is {0}", Triangle.Area());
            Console.WriteLine("Area of Rectangle is {0}", Rectangle.Area());
            Console.WriteLine("Area of Square is {0}", Square.Area());

            Triangle.Properties();

            Triangle.GetProperties();
        }
    }
}
