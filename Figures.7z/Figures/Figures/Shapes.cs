﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figures
{
	class Shapes
	{
		double perimeter;
		double area;

		string type;


		int widht;
		int height;

		public Shapes(string type, int widht, int height)
		{
			this.type = type;
			this.widht = widht;
			this.height = height;
		}
		public double Perimeter()
		{
			return this.perimeter;
		}

		private double RectangleArea(int a, int b)
		{
			return a * b;
		}

		public double Area()
		{
			switch (this.type)
			{
				case "triangle":
					this.area = (this.widht * this.height) / 2;
					break;

				case "rectangle":
					this.area = RectangleArea(this.widht , this.height) ;
					break;

				case "square":
					this.area = widht * height ;
					break;
			}
			return this.area;
		}

	}
}
