﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figures.Shapes
{
	class Square : BaseShape
	{
		int a;

		public Square(int a)
		{
			this.a = a;

		}

		public override double Perimeter()
		{
			this.perimeter = 4 * a;

			return this.perimeter;
		}


		public override double Area()
		{
			this.area = a ^ 2;
			return this.area;
		}
	}
}
