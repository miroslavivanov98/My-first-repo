﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figures.Shapes
{
	abstract class BaseShape
	{
		protected double perimeter;
		protected double area;
		protected double sides;

		abstract  public double Perimeter();
		abstract  public double Area();



		public virtual void Properties()
		{
			Console.WriteLine("Invoked in base class");

			Console.Write("I am {0}", this.GetType().ToString());
		}
	}
}
