﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figures.Shapes
{
	class Triangle : BaseShape
	{
		int first, second, third, height;



		public Triangle(int a, int b, int c, int h)
		{
			first = a;
			second = b;
			third = c;
			height = h;

			this.sides = 3;

		}


		public override double Perimeter()
		{
			this.perimeter = first + second + third;

			return this.perimeter;
		}


		public override double Area()
		{
			this.area = (first * height) / 2;
			return this.area;
		}

		public override void Properties()
		{
			Console.WriteLine("Invoked in derived class");
		}

		public void GetProperties()
		{
			Properties();

			base.Properties();

			Console.Write("and I have {0} sides",this.sides);
			Console.WriteLine();
		}

	}

}
