﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figures.Shapes
{
	class Rectangle : BaseShape
	{
		int width, height;

		public override double Perimeter()
		{
			this.perimeter = 2 * (width + height);

			return this.perimeter;
		}


		public override double Area()
		{
			this.area = width * height ;
			return this.area;
		}
	}
}
