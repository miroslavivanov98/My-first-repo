﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Figures
{
	using Shapes;

	class Program
	{
		static void Main(string[] args)
		{
			Shapes Triangle = new Shapes("triagle", 100, 100,100,10);
			
			Shapes Rectangle = new Shapes("rectangle", 10, 20);
			Shapes Square = new Shapes(10);

			Console.WriteLine("Area of Triagle is :{0}", Triangle.Area());
			Console.WriteLine("Area of Rectangle is :{0}", Rectangle.Area());
			Console.WriteLine("Area of Square is :{0}", Square.Area());


			Triangle.GetProperties();

			Square.Properties();
		}
	}
}
