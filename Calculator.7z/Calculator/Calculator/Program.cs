﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
	class Program
	{
		class Calculator<T>
		{
			public T Addition(T left,T right)
			{
				dynamic a = left;
				dynamic b = right;

				return a + b;
			}
			public T Substraction(T left, T right)
			{
				string lType, rType;
				lType = left.GetType().ToString().ToLower();
				rType = right.GetType().ToString().ToLower();


				if (left.GetType().ToString().ToLower()=="string")
				{
					throw new Exception("Both arguments must be of same type !");
				}

				if (lType == rType)
				{
					throw new Exception("Cannot substract strings");
				}

				dynamic a = left;
				dynamic b = right;

				return a - b;
			}
			public T Multiplication(T left, T right)
			{
				dynamic a = left;
				dynamic b = right;

				return a * b;
			}
			public T Division(T left, T right)
			{
				dynamic a = left;
				dynamic b = right;

				return a / b;
			}
		}

		static void Main(string[] args)
		{
			Calculator<int> intCalc = new Calculator<int>();
			Calculator<double> dblCalc = new Calculator<double>();
			Calculator<object> objCalc = new Calculator<object>();

			objCalc.Division((object)"asdf", (object)22);

			intCalc.Addition(3, 4);
			dblCalc.Division(20.5, 5.2);
		}
	}
}
